import {schoolForEmail} from './data.ts';
import {consumeRateLimit} from './rate-limit.ts';
type Environment={FIREBASE_API_KEY?:string;FIREBASE_PROJECT_ID?:string;DB?:D1Database;BUCKET?:R2Bucket};
const fail=(error:string,status:number)=>Response.json({error},{status,headers:{'Cache-Control':'no-store'}});
export async function materialRequest(request:Request,id:string,e:Environment,upstream:typeof fetch=fetch){
 if(request.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return fail('Request origin not allowed.',403);
 if(!/^[a-f0-9-]{36}$/.test(id))return fail('Material not found.',404);
 if(!e.FIREBASE_API_KEY||!e.FIREBASE_PROJECT_ID||!e.DB||!e.BUCKET)return fail('Uploads are not connected yet.',503);
 const token=request.headers.get('authorization')?.match(/^Bearer (.+)$/)?.[1];if(!token||token.length>8192)return fail('Sign in first.',401);
 try{
  const ip=request.headers.get('cf-connecting-ip')||'unknown';
  const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(ip)))).map(x=>x.toString(16).padStart(2,'0')).join('');
  if(!(await consumeRateLimit(e.DB,'materials-ip:'+hash,60,60000)).allowed)return fail('Too many requests. Try again in a minute.',429);
  const account=await upstream('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key='+encodeURIComponent(e.FIREBASE_API_KEY),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idToken:token}),signal:AbortSignal.timeout(10000)});
  if(!account.ok)return fail('Sign in again.',401);
  const user=(await account.json() as {users?:{localId:string;email:string;emailVerified:boolean;disabled?:boolean}[]}).users?.[0];
  const school=user&&schoolForEmail(user.email);if(!user||!user.emailVerified||user.disabled||!school)return fail('Verify your college email first.',403);
  if(!(await consumeRateLimit(e.DB,'materials-user:'+user.localId,30,60000)).allowed)return fail('Too many requests. Try again in a minute.',429);
  const metadata=await upstream('https://firestore.googleapis.com/v1/projects/'+encodeURIComponent(e.FIREBASE_PROJECT_ID)+'/databases/(default)/documents/Materials/'+id,{headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(10000)});
  if(!metadata.ok)return fail('Material unavailable.',metadata.status===404?404:403);
  const fields=(await metadata.json() as {fields:Record<string,{stringValue?:string;integerValue?:string;timestampValue?:string}>}).fields;
  const text=(key:string)=>fields[key]?.stringValue;
  if(text('school')!==school)return fail('This material belongs to another school.',403);
  const owner=text('uid');if(!owner||!/^[a-zA-Z0-9_-]{1,128}$/.test(owner))return fail('Invalid material owner.',400);
  const key='materials/'+school+'/'+owner+'/'+id+'.pdf';
  if(request.method==='GET'){
   if(text('status')!=='ready')return fail('Material is not ready.',404);
   const object=await e.BUCKET.get(key);if(!object)return fail('Material not found.',404);
   const name=(text('name')||'course-material.pdf').replace(/[^a-zA-Z0-9._ ()-]/g,'_');
   return new Response(object.body,{headers:{'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="'+name+'"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});
  }
  if(owner!==user.localId)return fail('Only the uploader can change this file.',403);
  if(request.method==='DELETE'){await e.BUCKET.delete(key);return Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});}
  if(request.method!=='PUT')return fail('Method not allowed.',405);
  const created=Date.parse(fields.createdAt?.timestampValue||'');const size=Number(fields.size?.integerValue);
  if(text('status')!=='pending'||!Number.isFinite(created)||Date.now()-created>600000||created>Date.now()+60000)return fail('Upload reservation expired.',409);
  if(!Number.isInteger(size)||size<5||size>10485760||request.headers.get('content-type')!=='application/pdf')return fail('Choose a PDF no larger than 10 MB.',400);
  const reader=request.body?.getReader();if(!reader)return fail('Choose a PDF.',400);
  const chunks:Uint8Array[]=[];let total=0;while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>size){await reader.cancel();return fail('File exceeds reserved size.',413);}chunks.push(value);}
  if(total!==size)return fail('File size does not match its reservation.',400);
  const bytes=new Uint8Array(total);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  if(new TextDecoder().decode(bytes.subarray(0,5))!=='%PDF-')return fail('This is not a PDF.',400);
  const saved=await e.BUCKET.put(key,bytes,{onlyIf:new Headers({'If-None-Match':'*'}),httpMetadata:{contentType:'application/pdf',contentDisposition:'attachment'}});
  if(!saved)return fail('This file already exists.',409);
  return Response.json({ok:true},{headers:{'Cache-Control':'no-store'}});
 }catch{return fail('Materials are temporarily unavailable. Please retry.',503);}
}
