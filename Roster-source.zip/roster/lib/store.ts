import {getApps,initializeApp} from 'firebase/app';
import {getAuth,createUserWithEmailAndPassword,signInWithEmailAndPassword,sendEmailVerification,sendPasswordResetEmail,updateProfile,signOut,onAuthStateChanged,type User} from 'firebase/auth';
import {getFirestore,collection,doc,query,where,orderBy,limit,onSnapshot,runTransaction,serverTimestamp,updateDoc,deleteDoc} from 'firebase/firestore';

import {schoolForEmail,validReview,type School,type Review,type Material,type Course} from './data';
export type Session={uid:string;email:string;name:string;school:School|null;verified:boolean};
export function session(user:User|null):Session|null{return user?{uid:user.uid,email:user.email||'',name:user.displayName||'Student',school:schoolForEmail(user.email||''),verified:user.emailVerified}:null;}
export async function connectStore(){
 if(location.protocol==='file:')return null;
 const response=await fetch('/api/config');if(!response.ok)throw Error('Unable to connect. Please retry.');
 const {firebase}=await response.json() as {firebase:Record<string,string>|null};if(!firebase)return null;
 const app=getApps()[0]||initializeApp(firebase);const auth=getAuth(app),db=getFirestore(app);
 async function materialCall(id:string,method:string,body?:File){const token=await auth.currentUser?.getIdToken();const response=await fetch('/api/materials/'+id,{method,headers:{Authorization:'Bearer '+token,...(body?{'Content-Type':'application/pdf'}:{})},body});if(!response.ok){const data=await response.json().catch(()=>({})) as {error?:string};throw Error(data.error||'Unable to access this material.');}return response;}
 function student(school:School){const u=auth.currentUser;if(!u||!u.emailVerified||schoolForEmail(u.email||'')!==school)throw Error('Verify an email from this school to contribute.');return u;}
 async function reserve(kind:'reviews'|'uploads',id:string,data:Record<string,unknown>){
  const user=student(data.school as School),quota=doc(db,'Limits',user.uid+'_'+kind),target=doc(db,kind==='reviews'?'Reviews':'Materials',id);
  await runTransaction(db,async tx=>{const old=await tx.get(quota);const value=old.data();const active=value&&Date.now()-value.windowStart.toMillis()<3600000;const count=active?value.count+1:1;
   if(count>5)throw Error('Hourly limit reached. You can contribute again after the current hour resets.');
   tx.set(quota,{uid:user.uid,kind,count,windowStart:active?value.windowStart:serverTimestamp(),updatedAt:serverTimestamp(),resourceId:id});
   tx.set(target,{...data,uid:user.uid,author:(user.displayName||'Student').slice(0,60),createdAt:serverTimestamp()});
  });
 }
 return {
  observe:(callback:(s:Session|null)=>void)=>onAuthStateChanged(auth,u=>callback(session(u))),
  async signup(name:string,email:string,password:string,school:School){if(schoolForEmail(email)!==school)throw Error('Use an email belonging to the school you selected.');if(name.trim().length<2||name.length>60)throw Error('Enter a name between 2 and 60 characters.');if(password.length<10)throw Error('Use a password of at least 10 characters.');const {user}=await createUserWithEmailAndPassword(auth,email.trim().toLowerCase(),password);await updateProfile(user,{displayName:name.trim()});try{await sendEmailVerification(user);}catch{throw Error('Account created, but the verification email could not be sent. Use Resend verification in your account.');}return session(user);},
  async login(email:string,password:string){const result=await signInWithEmailAndPassword(auth,email.trim(),password);return session(result.user);},
  logout:()=>signOut(auth),
  async reset(email:string){if(!schoolForEmail(email))throw Error('Enter your college email first.');await sendPasswordResetEmail(auth,email.trim());},
  async verify(){if(auth.currentUser)await sendEmailVerification(auth.currentUser);},
  async refresh(){if(auth.currentUser){await auth.currentUser.reload();await auth.currentUser.getIdToken(true);}return session(auth.currentUser);},
  async token(){if(!auth.currentUser?.emailVerified)throw Error('Verify your college email first.');return auth.currentUser.getIdToken();},
  watchReviews(school:School,callback:(r:Review[])=>void,onError:(e:Error)=>void){return onSnapshot(query(collection(db,'Reviews'),where('school','==',school),orderBy('createdAt','desc'),limit(100)),s=>callback(s.docs.map(d=>({...d.data(),id:d.id} as Review))),onError);},
  watchMaterials(school:School,callback:(r:Material[])=>void,onError:(e:Error)=>void){return onSnapshot(query(collection(db,'Materials'),where('school','==',school),orderBy('createdAt','desc'),limit(100)),s=>callback(s.docs.map(d=>({...d.data(),id:d.id} as Material)).filter(m=>m.status==='ready')),onError);},
  async review(course:Course,values:{body:string;tip:string;professor:string;difficulty:number}){if(!validReview(values))throw Error('Please complete all review fields within their limits.');const user=student(course.school);await reserve('reviews',user.uid+'_'+course.id,{...values,school:course.school,course:course.id});},
  async removeReview(id:string){await deleteDoc(doc(db,'Reviews',id));},
  async upload(course:Course,file:File,kind:string){const user=student(course.school);if(!file.name.toLowerCase().endsWith('.pdf')||file.size>10*1024*1024||file.size<5)throw Error('Choose a PDF no larger than 10 MB.');if(new TextDecoder().decode(await file.slice(0,5).arrayBuffer())!=='%PDF-')throw Error('The file is not a valid PDF.');const id=crypto.randomUUID();const name=file.name.replace(/[^a-zA-Z0-9._ ()-]/g,'_').replace(/\.pdf$/i,'').slice(0,116)+'.pdf';await reserve('uploads',id,{school:course.school,course:course.id,name,kind,size:file.size,status:'pending'});try{await materialCall(id,'PUT',file);await updateDoc(doc(db,'Materials',id),{status:'ready'});}catch(error){await materialCall(id,'DELETE').then(()=>deleteDoc(doc(db,'Materials',id))).catch(()=>{});throw error;}},
  async download(material:Material){student(material.school);const bytes=await (await materialCall(material.id,'GET')).arrayBuffer();const url=URL.createObjectURL(new Blob([bytes],{type:'application/pdf'}));const a=document.createElement('a');a.href=url;a.download=material.name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);},
  async removeMaterial(material:Material){await materialCall(material.id,'DELETE');await deleteDoc(doc(db,'Materials',material.id));},
 };
}
export type Store=NonNullable<Awaited<ReturnType<typeof connectStore>>>;
export function friendlyError(error:unknown){const code=(error as {code?:string})?.code;if(['auth/invalid-credential','auth/user-not-found','auth/wrong-password'].includes(code||''))return 'Email or password is incorrect.';if(code==='auth/email-already-in-use')return 'Unable to create this account. Try signing in or resetting your password.';if(code==='auth/too-many-requests')return 'Too many attempts. Please wait before trying again.';if(code==='permission-denied'||code==='storage/unauthorized')return 'Access denied. Verify your college email and try again.';if(code)return 'Unable to complete this action. Check your connection and try again.';return error instanceof Error?error.message:'Unable to complete this action.';}


