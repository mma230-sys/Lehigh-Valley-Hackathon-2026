export const schools = [
  {id:'lehigh', name:'Lehigh University', domain:'lehigh.edu', rmp:509},
  {id:'bucknell', name:'Bucknell University', domain:'bucknell.edu', rmp:140},
  {id:'harvard', name:'Harvard University', domain:'harvard.edu', rmp:399},
] as const;
export type School = typeof schools[number]['id'];
export type Resource = {name:string;url:string;cost:string;note:string};
export type Course = {id:string;code:string;name:string;school:School;dept:string;color:string;source:string;resources:Resource[]};
// Catalog facts only. No invented professors, reviews, prices, or weekly hours.
const calculus:Resource={name:'OpenStax Calculus Volume 1',url:'https://openstax.org/details/books/calculus-volume-1',cost:'Free digital edition',note:'Optional supplement; check your syllabus for the assigned edition.'};
export const courses:Course[]=[
 {id:'lehigh-cse017',code:'CSE 017',name:'Programming and Data Structures',school:'lehigh',dept:'Computer Science',color:'purple',source:'https://catalog.lehigh.edu/courselisting/cse/',resources:[{name:'Java learning resources',url:'https://dev.java/learn/',cost:'Free online',note:'Official Java reference; not a confirmed assigned textbook.'}]},
 {id:'lehigh-math021',code:'MATH 021',name:'Calculus I',school:'lehigh',dept:'Mathematics',color:'blue',source:'https://catalog.lehigh.edu/courselisting/math/',resources:[calculus]},
 {id:'lehigh-psyc001',code:'PSYC 001',name:'Introduction to Psychology',school:'lehigh',dept:'Psychology',color:'pink',source:'https://catalog.lehigh.edu/courselisting/psyc/',resources:[{name:'OpenStax Psychology 2e',url:'https://openstax.org/details/books/psychology-2e',cost:'Free digital edition',note:'Optional supplement; not a confirmed assigned textbook.'}]},
 {id:'lehigh-eco001',code:'ECO 001',name:'Principles of Economics',school:'lehigh',dept:'Economics',color:'orange',source:'https://catalog.lehigh.edu/courselisting/eco/',resources:[{name:'OpenStax Principles of Economics 3e',url:'https://openstax.org/details/books/principles-economics-3e',cost:'Free digital edition',note:'Optional supplement; required materials vary by section.'}]},
 {id:'bucknell-csci203',code:'CSCI 203',name:'Introduction to Computer Science',school:'bucknell',dept:'Computer Science',color:'purple',source:'https://coursecatalog.bucknell.edu/courses/csci/',resources:[{name:'CSCI 203 course websites',url:'https://csci.courses.bucknell.edu/category/203/',cost:'See section syllabus',note:'Official section pages link to course materials. No price has been assumed.'}]},
 {id:'harvard-cs50',code:'CS50',name:'Introduction to Computer Science',school:'harvard',dept:'Computer Science',color:'green',source:'https://cs50.harvard.edu/college/2026/fall/syllabus/',resources:[{name:'CS50 syllabus and course materials',url:'https://cs50.harvard.edu/college/2026/fall/syllabus/',cost:'Public online materials',note:'Consult the official syllabus for assigned materials and requirements.'}]},
];
export const workloadSource='https://data.lehigh.edu/weekly-course-commitment';
export const workloadEmbed='https://public.tableau.com/views/HoursSpentbyCourse/TimeSpentDashboard?:showVizHome=no&:embed=true';
export type Review={id:string;course:string;school:School;uid:string;author:string;body:string;tip:string;difficulty:number;professor:string;createdAt?:{seconds:number}};
export type Material={id:string;course:string;school:School;uid:string;author:string;name:string;kind:string;size:number;status:'pending'|'ready';createdAt?:{seconds:number}};
export function schoolForEmail(email:string):School|null {
 const domain=email.trim().toLowerCase().split('@');
 if(domain.length!==2||!domain[0])return null;
 return schools.find(s=>domain[1]===s.domain||domain[1].endsWith('.'+s.domain))?.id??null;
}
export function courseStats(course:string,reviews:Review[]){
 const selected=reviews.filter(r=>r.course===course);
 return {count:selected.length,difficulty:selected.length?(selected.reduce((s,r)=>s+r.difficulty,0)/selected.length).toFixed(1):null,tips:selected.filter(r=>r.tip.trim())};
}
export function validReview(value:{body:string;tip:string;professor:string;difficulty:number}){
 return value.body.trim().length>=20&&value.body.length<=3000&&value.tip.trim().length>=10&&value.tip.length<=600&&value.professor.trim().length>=2&&value.professor.length<=100&&Number.isInteger(value.difficulty)&&value.difficulty>=1&&value.difficulty<=5;
}

