export async function consumeRateLimit(db:D1Database,key:string,maximum:number,windowMs:number,now=Date.now()){
 const start=Math.floor(now/windowMs)*windowMs;
 const row=await db.prepare('INSERT INTO rate_limits (key, window_start, count) VALUES (?, ?, 1) ON CONFLICT(key) DO UPDATE SET count = CASE WHEN rate_limits.window_start = excluded.window_start THEN MIN(rate_limits.count + 1, ?) ELSE 1 END, window_start = excluded.window_start RETURNING count').bind(key,start,maximum+1).first<{count:number}>();
 if(!row)throw Error('Rate limiter unavailable');
 return {allowed:row.count<=maximum,retryAfter:Math.max(1,Math.ceil((start+windowMs-now)/1000))};
}

