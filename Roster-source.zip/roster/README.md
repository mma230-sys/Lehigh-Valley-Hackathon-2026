# Roster

A responsive campus course app for Lehigh University, Bucknell University, and Harvard University. Built with Next.js App Router components, React, TypeScript, Firebase, and the Sites Vinext/Cloudflare runtime.

## What changed

- Survival tips are **verbatim student submissions**, attached to their original review and professor. No seeded reviews, fake students, AI tips, invented ratings, or invented weekly hours.
- Each account has one review per course. Difficulty averages individual ratings in the latest 100 campus reviews; the visible sample size is shown.
- Rate My Professors is an **in-page, provider-hosted viewer**, not a scraped or copied database. Lehigh professor navigation and actual reviews were verified in the browser on October 17, 2026. Third-party embedding may change.
- Lehigh workload is the live Tableau workbook linked by [Lehigh Institutional Data](https://data.lehigh.edu/weekly-course-commitment). The dashboard and term filters were verified in the browser. No figures are copied onto cards without a verified data import. Bucknell and Harvard do not inherit Lehigh estimates.
- Official catalog links and learning-resource links replace invented textbook costs. Free resources are explicitly optional supplements unless the official syllabus says otherwise.
- Study Trades and the fictional social/demo records are removed. This version does not claim working friend schedules or messaging.
- Signup, login, email verification, resend verification, password reset, and sign-out use Firebase Authentication. Registration includes school selection and a matching university email.
- Shared reviews use Firestore. PDF uploads use protected Sites R2 storage and Firestore metadata. College mailbox ownership is verified; course enrollment is not.
- Mobile navigation, accessible forms/dialogs, success/error notices, clickable logos, metadata, working footer dialogs, custom 404, current copyright year, and the requested production masthead are included.
- App artwork consists of SVG icons and CSS; no large raster images are shipped. Production assets are minified, and Firebase loads separately.

## Run

Node 22.13+ (Node 24 recommended):

```sh
npm install
npm run dev
npm run build
npm test
```

The app uses Vinext/Vite for Cloudflare deployment, not stock `next build`.

`node scripts/preview-demo.mjs` serves the interface on port 5174 with services disabled. `/mobile` is a local-only 390px layout test harness. The adjacent `Roster-demo.html` is the self-contained preview; **it cannot provide live accounts, uploads, or server API calls**. It does not silently simulate successful submissions.

## Firebase configuration

Firebase project `roster-campus-2026-a14b` is provisioned in US East with Email/Password Authentication and Firestore rules deployed. Configure these runtime values in Sites (never commit private keys):

- FIREBASE_API_KEY (public Web configuration)
- FIREBASE_PROJECT_ID
- FIREBASE_AUTH_DOMAIN
- FIREBASE_APP_ID

Enable Email/Password Authentication and authorize the deployed host. Disable unused providers. Set a minimum password length of 10 and enable email enumeration protection in the Firebase console.

Deploy Firestore rules and indexes. Sites provisions the private R2 BUCKET binding for PDFs; Firebase Storage billing is not required. The server verifies Firebase sessions and Firestore upload reservations on each file request.

Use the official current CLI for project operations:

```sh
npx -y firebase-tools@latest login
npx -y firebase-tools@latest deploy --only auth,firestore --project YOUR_PROJECT_ID
```

The tracked `firebase.json` contains the provider configuration and rules. Replace/add authorized domains for the actual published app; do not include protocols or ports.

## Security and limits

- Rules enforce verified school domains (including genuine subdomains), ownership, allowed course/school pairs, field allowlists, types, text lengths, integer ratings, and server timestamps.
- Five review writes and five upload reservations per account per rolling one-hour window, enforced by atomic Firestore quota records and `getAfter` rules. Deleting a review does not reset the limit.
- Uploads require a fresh authorized reservation, matching byte size, PDF MIME type, attachment disposition, and a 10 MB maximum. Existing objects cannot be overwritten.
- Client and server check PDF magic bytes. This does not scan malware. Files are downloaded as attachments; there is no automatic inline rendering. Production scanning/moderation remains future work.
- Public review list requests are bounded to 100 documents. Material reads require a verified email at the same school. Owners can delete their contributions.
- Syllabus API checks origin, validates Firebase sessions via Google's account lookup endpoint, rejects unsupported/unverified email domains, limits body bytes while streaming, and validates PDF magic bytes.
- Material API requests are limited to 60/minute/IP and 30/minute/account, in addition to the five upload reservations/hour.
- Persistent atomic D1 limits: 10 syllabus requests/minute/IP and 3 analyses/hour/account. Limits fail closed if the D1 binding is unavailable. The schema migration is in `drizzle/`.
- The Worker adds a CSP, nosniff, restricted device permissions, and a referrer policy. React escapes submitted text. API secrets remain server-side.
- Firebase also applies its own authentication quotas. App Check, automated moderation/reporting, malware scanning, and account deletion workflows are not yet implemented.

## Optional syllabus extraction

Configure OPENAI_API_KEY server-side; OPENAI_MODEL defaults to `gpt-4.1-mini`. The endpoint uses structured Responses API output for stated course facts, materials, USD prices, and grading weights. Unknown prices stay null. It has **no survival-tip field**, cannot publish reviews, and does not supply official workload data. PDF transmission requires the user's checkbox consent.

## Verification

- TypeScript and production Worker build pass.
- Four logic tests cover school-domain lookalikes, no synthetic review data, exact tip preservation/count-weighted ratings, and real SQLite execution of the atomic API limiter.
- Three Firebase emulator tests cover unverified/cross-school denial, direct-write/quota bypass rejection, review ownership, hourly limits, upload reservations, MIME checks, overwrite rejection, and school-restricted downloads.
- Browser checks confirmed the desktop interface, saving, student-review empty states, live RMP professor reviews, the live Lehigh Tableau dashboard, and a 390px mobile layout.
- The actual local production Worker was also checked: homepage 200, custom missing-page 404, metadata and security headers present, and cross-origin syllabus requests rejected with 403. Live signup/email delivery and real student upload round trips still require a verified student account.

Run rule tests with `npm run test:rules`. The local validation used Firebase CLI 13.35.1 and Java 11, with the emulator artifacts cached outside this source tree. The CLI's update notifier emitted a local config permission warning after the test runner passed; this did not affect the rule assertions.

## Data sources

- Lehigh catalog: https://catalog.lehigh.edu/courselisting/
- Bucknell CSCI catalog: https://coursecatalog.bucknell.edu/courses/csci/
- Harvard CS50 syllabus: https://cs50.harvard.edu/college/2026/fall/syllabus/
- Lehigh workload: https://data.lehigh.edu/weekly-course-commitment
- RMP school IDs: Lehigh 509, Bucknell 140, Harvard 399.
- Optional free resources: OpenStax and dev.java; follow the links in each course card.

A production of Shaan Chopra, Adam Eladly, and Mostafa Ashosh

