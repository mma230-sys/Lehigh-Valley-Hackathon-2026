// Portable demo preview for hosts where the Cloudflare Worker runtime cannot run.
// Renders the same React app. Production API route handlers remain in app/api.
import {createRequire} from 'node:module';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {createServer} from 'node:http';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const require=createRequire(import.meta.url);const {buildSync}=require('esbuild');
const root=fileURLToPath(new URL('../',import.meta.url));const out=path.join(root,'.preview');mkdirSync(out,{recursive:true});
buildSync({stdin:{contents:"import React from 'react';import {createRoot} from 'react-dom/client';import Home from './app/page';import './app/globals.css';createRoot(document.getElementById('root')).render(<Home/>);",resolveDir:root,loader:'tsx'},bundle:true,format:'esm',platform:'browser',jsx:'automatic',minify:true,outfile:path.join(out,'app.js'),define:{'process.env.NODE_ENV':'"production"'},logLevel:'warning'});
writeFileSync(path.join(out,'index.html'),'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Student-written course reviews, survival tips, and campus materials for Lehigh, Bucknell, and Harvard."><title>Roster — Student reviews &amp; campus survival tips</title><link rel="stylesheet" href="/app.css"></head><body><div id="root"></div><script type="module" src="/app.js"></script></body></html>');
const server=createServer(async(req,res)=>{
 if(req.url==='/mobile'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><head><title>Roster mobile QA</title></head><body style="margin:0;background:#080c12;display:flex;justify-content:center"><iframe title="Roster at 390 pixels" src="/" style="width:390px;height:844px;border:0"></iframe></body></html>');return;}
 if(req.url==='/api/config'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({firebase:null,aiEnabled:false}));return;}
 if(req.url==='/api/syllabus'){res.writeHead(503,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Syllabus analysis is not connected yet.'}));return;}
 const files={'/':'index.html','/app.js':'app.js','/app.css':'app.css'};const file=files[req.url];if(!file){res.writeHead(404);res.end('Not found');return;}
 res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':'text/html');res.end(readFileSync(path.join(out,file)));
});
if(!process.argv.includes('--build-only'))server.listen(Number(process.env.PORT||5174),'127.0.0.1',()=>console.log('Roster preview: http://127.0.0.1:'+(process.env.PORT||5174)));
