import {integer,sqliteTable,text} from 'drizzle-orm/sqlite-core';
export const rateLimits=sqliteTable('rate_limits',{key:text('key').primaryKey(),windowStart:integer('window_start').notNull(),count:integer('count').notNull()});

