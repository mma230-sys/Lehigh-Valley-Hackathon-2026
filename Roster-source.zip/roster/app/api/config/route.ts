import {env} from 'cloudflare:workers';
export async function GET(){const e=env as unknown as Record<string,string|undefined>;return Response.json({firebase:e.FIREBASE_API_KEY&&e.FIREBASE_PROJECT_ID?{apiKey:e.FIREBASE_API_KEY,authDomain:e.FIREBASE_AUTH_DOMAIN||e.FIREBASE_PROJECT_ID+'.firebaseapp.com',projectId:e.FIREBASE_PROJECT_ID,appId:e.FIREBASE_APP_ID,storageBucket:e.FIREBASE_STORAGE_BUCKET}:null,aiEnabled:!!e.OPENAI_API_KEY},{headers:{'Cache-Control':'no-store'}});}

