import {env} from 'cloudflare:workers';
import {materialRequest} from '../../../../lib/material-api';
async function handle(request:Request,context:{params:Promise<{id:string}>}){return materialRequest(request,(await context.params).id,env);}
export {handle as GET,handle as PUT,handle as DELETE};
