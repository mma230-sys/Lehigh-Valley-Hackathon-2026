import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Roster — Student reviews, course materials & campus survival tips",
  description: "Firsthand course reviews, student-written survival tips, and shared materials for Lehigh, Bucknell, and Harvard. Plan your semester with clearly attributed sources.",
  openGraph: {title: "Roster — Your semester. Less guesswork.", description: "Student-written course advice and campus materials for Lehigh, Bucknell, and Harvard.", type: "website"},
  twitter: {card: "summary", title: "Roster — Your semester. Less guesswork.", description: "Student-written course advice, with the source always in view."},
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
