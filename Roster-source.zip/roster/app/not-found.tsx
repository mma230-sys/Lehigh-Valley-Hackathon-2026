import Link from 'next/link';
export default function NotFound(){return <main className="not-found"><a className="brand" href="/">roster<span className="brand-dot">.</span></a><span className="eyebrow">404 · OFF THE ROSTER</span><h1>This page missed class.</h1><p>The address may have changed. Your next course is still out there.</p><Link className="primary" href="/">Back to Explore</Link></main>;}

