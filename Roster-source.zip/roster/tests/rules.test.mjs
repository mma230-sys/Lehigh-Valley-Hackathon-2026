import {before,after,beforeEach,test} from 'node:test';
import {readFileSync} from 'node:fs';
import {initializeTestEnvironment,assertFails,assertSucceeds} from '@firebase/rules-unit-testing';
import {doc,setDoc,getDoc,getDocs,collection,query,where,limit,runTransaction,serverTimestamp,updateDoc,deleteDoc} from 'firebase/firestore';
import {ref,uploadBytes,getBytes} from 'firebase/storage';
let env;
before(async()=>{env=await initializeTestEnvironment({projectId:'demo-roster',firestore:{rules:readFileSync('firestore.rules','utf8')},storage:{rules:readFileSync('storage.rules','utf8')}});});
after(async()=>{await env?.cleanup();});
beforeEach(async()=>{await env.clearFirestore();await env.clearStorage();});
const context=(uid='student',email='student@lehigh.edu',verified=true)=>env.authenticatedContext(uid,{email,email_verified:verified});
const data={course:'lehigh-cse017',school:'lehigh',author:'Real Student',body:'I attended this course and this is my own review.',tip:'Here is my firsthand advice.',professor:'Professor Student Named',difficulty:3};
async function publish(ctx,overrides={}){
 const db=ctx.firestore(),uid=ctx.authToken?.sub||'student';
 // Tests explicitly use student except when checking direct forbidden access.
 const q=doc(db,'Limits','student_reviews'),r=doc(db,'Reviews','student_lehigh-cse017');
 return runTransaction(db,async tx=>{const old=await tx.get(q);const d=old.data();tx.set(q,{uid:'student',kind:'reviews',count:d?d.count+1:1,windowStart:d?d.windowStart:serverTimestamp(),updatedAt:serverTimestamp(),resourceId:r.id});tx.set(r,{...data,uid:'student',createdAt:serverTimestamp(),...overrides});});
}
test('only verified matching-school accounts can publish; direct writes cannot bypass quota',async()=>{
 await assertFails(publish(context('student','student@lehigh.edu',false)));
 await assertFails(publish(context('student','student@harvard.edu')));
 await assertFails(publish(context('student','student@fakelehigh.edu')));
 await assertFails(setDoc(doc(context().firestore(),'Reviews','student_lehigh-cse017'),{...data,uid:'student',createdAt:serverTimestamp()}));
 await assertSucceeds(publish(context()));
 await assertSucceeds(getDocs(query(collection(env.unauthenticatedContext().firestore(),'Reviews'),limit(100))));
 await assertFails(getDocs(collection(env.unauthenticatedContext().firestore(),'Reviews')));
});
test('server validation rejects score and ownership changes; review quota survives client restarts',async()=>{
 await assertFails(publish(context(),{difficulty:6}));
 await assertSucceeds(publish(context()));
 await assertFails(updateDoc(doc(context('other','other@lehigh.edu').firestore(),'Reviews','student_lehigh-cse017'),{tip:'Changed by someone else'}));
 for(let i=1;i<5;i++)await assertSucceeds(publish(context()));
 await assertFails(publish(context()));
 await assertFails(deleteDoc(doc(context().firestore(),'Limits','student_reviews')));
 await assertSucceeds(deleteDoc(doc(context().firestore(),'Reviews','student_lehigh-cse017')));
});
test('file uploads need a reservation; downloads are restricted to the same verified school',async()=>{
 const id='11111111-1111-4111-8111-111111111111',file=new TextEncoder().encode('%PDF-1.4 test fixture');
 const student=context(),db=student.firestore(),object=ref(student.storage(),'materials/lehigh/student/'+id+'.pdf');
 await assertFails(uploadBytes(object,file,{contentType:'application/pdf',contentDisposition:'attachment'}));
 await runTransaction(db,async tx=>{tx.set(doc(db,'Limits','student_uploads'),{uid:'student',kind:'uploads',count:1,windowStart:serverTimestamp(),updatedAt:serverTimestamp(),resourceId:id});tx.set(doc(db,'Materials',id),{uid:'student',author:'Student',school:'lehigh',course:'lehigh-cse017',name:'notes.pdf',kind:'Notes',size:file.length,status:'pending',createdAt:serverTimestamp()});});
 await assertFails(uploadBytes(object,file,{contentType:'text/html',contentDisposition:'attachment'}));
 await assertSucceeds(uploadBytes(object,file,{contentType:'application/pdf',contentDisposition:'attachment'}));
 await assertFails(uploadBytes(object,file,{contentType:'application/pdf',contentDisposition:'attachment'}));
 await assertSucceeds(getBytes(ref(context('peer','peer@lehigh.edu').storage(),'materials/lehigh/student/'+id+'.pdf')));
 await assertFails(getBytes(ref(context('outsider','outsider@harvard.edu').storage(),'materials/lehigh/student/'+id+'.pdf')));
 await assertFails(getDoc(doc(context('outsider','outsider@harvard.edu').firestore(),'Materials',id)));
});

