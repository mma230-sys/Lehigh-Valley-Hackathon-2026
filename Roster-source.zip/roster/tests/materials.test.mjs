import {test} from 'node:test';
import assert from 'node:assert/strict';
import {materialRequest} from '../lib/material-api.ts';
const id='12345678-1234-1234-1234-123456789abc';
function fixture({verified=true,school='lehigh',owner='student',status='pending',exists=false}={}){
 const writes=[];const e={FIREBASE_API_KEY:'test',FIREBASE_PROJECT_ID:'test',DB:{prepare(){return {bind(){return {async first(){return {count:1}}}}}}},BUCKET:{async put(key,bytes,options){writes.push({key,bytes,options});return exists?null:{}},async get(){return {body:new Uint8Array([1,2])}},async delete(key){writes.push(key)}}};
 const upstream=async url=>url.includes('accounts:lookup')?Response.json({users:[{localId:'student',email:'student@lehigh.edu',emailVerified:verified}]}):Response.json({fields:{school:{stringValue:school},uid:{stringValue:owner},status:{stringValue:status},size:{integerValue:'9'},createdAt:{timestampValue:new Date().toISOString()},name:{stringValue:'notes.pdf'}}});
 const send=(method='PUT',body='%PDF-test',headers={})=>materialRequest(new Request('https://roster.test/api/materials/'+id,{method,headers:{Authorization:'Bearer test','Content-Type':'application/pdf',...headers},...(method==='PUT'?{body}: {})}),id,e,upstream);
 return {send,writes};
}
test('material API rejects unverified, other-school, and non-owner writes',async()=>{
 for(const options of [{verified:false},{school:'harvard'},{owner:'someone-else'}])assert.equal((await fixture(options).send()).status,403);
 assert.equal((await fixture().send('PUT','%PDF-test',{Origin:'https://evil.test'})).status,403);
});
test('material API validates reservation size, magic bytes, and atomic create condition',async()=>{
 assert.equal((await fixture({status:'ready'}).send()).status,409);
 assert.equal((await fixture().send('PUT','not-a-pdf')).status,400);
 assert.equal((await fixture().send('PUT','%PDF-too-long')).status,413);
 assert.equal((await fixture({exists:true}).send()).status,409);
 const f=fixture();assert.equal((await f.send()).status,200);assert.equal(f.writes.length,1);assert.equal(f.writes[0].options.onlyIf.get('If-None-Match'),'*');
});
test('downloads require ready status and force attachment; deletion requires ownership',async()=>{
 assert.equal((await fixture().send('GET')).status,404);
 const result=await fixture({status:'ready'}).send('GET');assert.equal(result.status,200);assert.match(result.headers.get('Content-Disposition'),/^attachment/);assert.equal(result.headers.get('Cache-Control'),'private, no-store');
 assert.equal((await fixture({owner:'other'}).send('DELETE')).status,403);
 assert.equal((await fixture().send('DELETE')).status,200);
});
