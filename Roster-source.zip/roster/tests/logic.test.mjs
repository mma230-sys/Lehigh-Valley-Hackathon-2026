import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {courses,courseStats,schoolForEmail,validReview} from '../lib/data.ts';
import {consumeRateLimit} from '../lib/rate-limit.ts';
test('email domain gate rejects lookalikes and supports actual school subdomains',()=>{
 for(const [email,school] of [['a@lehigh.edu','lehigh'],['a@bucknell.edu','bucknell'],['a@college.harvard.edu','harvard'],[' A@HARVARD.EDU ','harvard']])assert.equal(schoolForEmail(email),school);
 for(const email of ['a@harvard.edu.evil.com','a@fakelehigh.edu','a@gmail.com','a@@lehigh.edu','@bucknell.edu'])assert.equal(schoolForEmail(email),null);
});
test('unreviewed courses have no synthetic scores or tips',()=>{
 for(const c of courses){assert.deepEqual(courseStats(c.id,[]),{count:0,difficulty:null,tips:[]});assert.ok(!('hours' in c));assert.ok(!('tip' in c));}
});
test('review ratings weight individual submissions and preserve exact advice',()=>{
 const a={id:'a',course:courses[0].id,school:'lehigh',uid:'a',author:'Student A',body:'A firsthand course review',tip:'My exact tip, punctuation intact!',difficulty:5,professor:'Professor A'};
 const b={...a,id:'b',uid:'b',difficulty:1,professor:'Professor B'};
 const c={...a,id:'c',uid:'c',difficulty:1};
 const stats=courseStats(a.course,[a,b,c,{...a,course:'other'}]);
 assert.equal(stats.difficulty,'2.3');assert.equal(stats.count,3);assert.equal(stats.tips[0].tip,a.tip);
 assert.equal(validReview(a),true);assert.equal(validReview({...a,difficulty:5.1}),false);assert.equal(validReview({...a,tip:'   '}),false);
});
test('persistent atomic API limits reject excess requests and reset at the boundary',async()=>{
 const sql=new DatabaseSync(':memory:');sql.exec(readFileSync(new URL('../drizzle/0000_fantastic_terror.sql',import.meta.url),'utf8'));
 const db={prepare(query){return {bind(...params){return {async first(){return sql.prepare(query).get(...params);}};}};}};
 const values=await Promise.all(Array.from({length:8},()=>consumeRateLimit(db,'student',3,3600000,1000)));
 assert.equal(values.filter(v=>v.allowed).length,3);
 assert.equal((await consumeRateLimit(db,'another-student',3,3600000,1000)).allowed,true);
 assert.equal((await consumeRateLimit(db,'student',3,3600000,3600000)).allowed,true);
 sql.close();
});

